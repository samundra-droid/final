import 'dart:async';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

void main() {
  runApp(const BankApp());
}

class BankApp extends StatelessWidget {
  const BankApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'MyBank',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.teal),
        useMaterial3: true,
      ),
      home: const SplashScreen(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    Timer(
      const Duration(seconds: 3),
      () {
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (context) => const WelcomeScreen()),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        width: double.infinity, // Ensure it takes full width
        height: double.infinity, // Ensure it takes full height
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [Colors.teal.shade900, Colors.teal.shade300],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: Center( // Center everything
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center, // Center vertically
            crossAxisAlignment: CrossAxisAlignment.center, // Center horizontally
            children: [
              Image.asset(
                'assets/bank.png',
                width: 150,
                height: 150,
              ),
              const SizedBox(height: 30),
              const Text(
                '"Secure your dreams, one step at a time."\nWelcome to Bank of America.',
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 18,
                  fontStyle: FontStyle.italic,
                  fontWeight: FontWeight.w600,
                  color: Colors.white,
                ),
              ),
              const SizedBox(height: 50),
              const CircularProgressIndicator(
                valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class WelcomeScreen extends StatelessWidget {
  const WelcomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final String formattedDate = DateFormat('EEEE, MMM d, yyyy').format(DateTime.now());

    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [Colors.teal.shade800, Colors.teal.shade300],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Image.asset(
                'assets/bank.png',
                width: 120,
                height: 120,
              ),
              const SizedBox(height: 20),
              const Text(
                'Welcome to Bank of America',
                style: TextStyle(
                  fontSize: 26,
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                ),
              ),
              const SizedBox(height: 10),
              Text(
                formattedDate,
                style: const TextStyle(
                  fontSize: 18,
                  color: Colors.white70,
                ),
              ),
              const SizedBox(height: 40),
              ElevatedButton(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => const AccountListScreen()),
                  );
                },
                style: ElevatedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 15),
                  backgroundColor: Colors.white,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(30),
                  ),
                ),
                child: const Text(
                  'View Accounts',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: Colors.teal,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class AccountListScreen extends StatelessWidget {
  const AccountListScreen({super.key});

  final List<Map<String, dynamic>> accounts = const [
    {
      "type": "Chequing",
      "account_number": "CHQ123456789",
      "balance": 2500.00
    },
    {
      "type": "Savings",
      "account_number": "SAV987654321",
      "balance": 5000.00
    }
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('My Accounts'),
        backgroundColor: Colors.teal.shade800,
      ),
      body: Container(
        padding: const EdgeInsets.all(16.0),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [Colors.teal.shade50, Colors.teal.shade100],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: ListView.builder(
          itemCount: accounts.length,
          itemBuilder: (context, index) {
            final account = accounts[index];

            return Card(
              margin: const EdgeInsets.symmetric(vertical: 10),
              elevation: 5,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(15),
              ),
              child: ListTile(
                leading: Icon(
                  account['type'] == 'Chequing' ? Icons.account_balance : Icons.savings,
                  color: Colors.teal.shade800,
                  size: 40,
                ),
                title: Text(
                  account['type'],
                  style: const TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                subtitle: Text(
                  'Account #: ${account['account_number']}\nBalance: \$${account['balance'].toStringAsFixed(2)}',
                ),
                isThreeLine: true,
                trailing: ElevatedButton(
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => TransactionDetailsScreen(accountType: account['type']),
                      ),
                    );
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.teal,
                  ),
                  child: const Text('View Transactions'),
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}

class TransactionDetailsScreen extends StatelessWidget {
  const TransactionDetailsScreen({super.key, required this.accountType});

  final String accountType;

  final Map<String, List<Map<String, dynamic>>> transactions = const {
    "Chequing": [
      {"date": "2024-04-14", "description": "Utility Bill Payment", "amount": -120.00},
      {"date": "2024-04-16", "description": "ATM Withdrawal", "amount": -75.00},
      {"date": "2024-04-17", "description": "Deposit", "amount": 100.00},
      {"date": "2024-04-18", "description": "Withdrawal", "amount": -50.00},
    ],
    "Savings": [
      {"date": "2024-04-12", "description": "Withdrawal", "amount": -300.00},
      {"date": "2024-04-15", "description": "Interest", "amount": 10.00},
      {"date": "2024-04-16", "description": "Deposit", "amount": 200.00},
      {"date": "2024-04-18", "description": "Transfer to Chequing", "amount": -500.00},
    ]
  };

  @override
  Widget build(BuildContext context) {
    final accountTransactions = transactions[accountType] ?? [];

    return Scaffold(
      appBar: AppBar(
        title: Text('$accountType Transactions'),
        backgroundColor: Colors.teal.shade800,
      ),
      body: Container(
        padding: const EdgeInsets.all(16.0),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [Colors.teal.shade50, Colors.teal.shade100],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: ListView.separated(
          itemCount: accountTransactions.length,
          separatorBuilder: (context, index) => const Divider(),
          itemBuilder: (context, index) {
            final transaction = accountTransactions[index];

            return ListTile(
              leading: Icon(
                transaction['amount'] >= 0 ? Icons.arrow_downward : Icons.arrow_upward,
                color: transaction['amount'] >= 0 ? Colors.green : Colors.red,
                size: 30,
              ),
              title: Text(transaction['description']),
              subtitle: Text(transaction['date']),
              trailing: Text(
                '\$${transaction['amount'].toStringAsFixed(2)}',
                style: TextStyle(
                  color: transaction['amount'] >= 0 ? Colors.green : Colors.red,
                  fontWeight: FontWeight.bold,
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}
